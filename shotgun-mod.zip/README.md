# Pump Shotgun (Fabric 1.20.1)

- **Right-click** fire (8 pellets, spread + falloff, hitscan)  |  **R** or **Sneak + Right-click** reload (6 shells)
- Craft shells: gunpowder + iron nugget + paper -> 4 shells. Shotgun: `III / IP_ / S__` (I iron ingot, P piston, S stick). Creative tab: Combat (reload is free in creative).
- Mobs shot by the gun spray red-concrete block-break particles ("blood"); big burst when they die.
- Sounds: `assets/shotgun/sounds/` (shoot / reload). Model: `assets/shotgun/mesh/shotgun.json` + `textures/item/shotgun_model.png`.

## Tweaking
- Hold position / sizes: top of `client/ShotgunRenderer.java` (SCALE_*, FP_OFFSET_*, FP_YAW, PUMP_TRAVEL).
- GUI / ground / third-person display: `assets/shotgun/models/item/shotgun.json` (reloads with F3+T).
- Damage, pellets, spread, cooldowns: top of `ShotgunItem.java`.

## Build
Push to GitHub; the workflow in `.github/workflows/build.yml` builds the jar (Actions > Artifacts, or the Releases page).
Locally: `gradle build` (Gradle 8.5, JDK 17) -> `build/libs/pump-shotgun-1.0.0.jar`.
