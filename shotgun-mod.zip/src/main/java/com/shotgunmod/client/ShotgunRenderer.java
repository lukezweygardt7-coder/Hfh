package com.shotgunmod.client;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.joml.Matrix3f;
import org.joml.Matrix4f;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shotgunmod.ShotgunItem;
import com.shotgunmod.ShotgunMod;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Draws the shotgun from baked mesh data (assets/shotgun/mesh/shotgun.json, generated from the
 * supplied .glb) and animates the rig:
 *  - "pump" group (forend, forend cap, charge handle, charge knob) slides along the barrel
 *  - whole gun kicks back / muzzle rises on firing
 *  - gun dips + rolls and pumps on reload
 * Animation progress comes from the vanilla item-cooldown, so no extra networking is needed.
 */
@Environment(EnvType.CLIENT)
public class ShotgunRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {
    private static final Identifier MESH_ID = ShotgunMod.id("mesh/shotgun.json");
    private static final Identifier TEXTURE = ShotgunMod.id("textures/item/shotgun_model.png");

    // ------------------------------------------------------------- tuning knobs
    /** Model units (glb "blocks") -> Minecraft blocks. Gun is ~3.6 units long. */
    private static final float SCALE_HAND = 0.30f;
    private static final float SCALE_THIRD = 0.26f;
    private static final float SCALE_OTHER = 0.26f;
    /** Grip pivot (trigger) in model units - the point the gun is held and recoils around. */
    private static final float GRIP_X = 0.0f, GRIP_Y = 0.50f, GRIP_Z = 0.36f;
    /** Model centre, used for GUI / ground / item frame. */
    private static final float CENTER_X = 0.04f, CENTER_Y = 0.55f, CENTER_Z = 0.16f;
    /** First-person placement relative to the vanilla hand position (blocks, right-hand sign). */
    private static final float FP_OFFSET_X = -0.20f, FP_OFFSET_Y = 0.12f, FP_OFFSET_Z = -0.15f;
    private static final float FP_YAW = 3.5f;
    /** How far the pump slides (model units). */
    private static final float PUMP_TRAVEL = 0.55f;

    // ---------------------------------------------------------------- mesh data
    private static final class Part {
        boolean pump;
        float[] data; // quads * 4 verts * 8 floats: x y z u v nx ny nz
    }

    private static List<Part> parts;

    private static List<Part> mesh() {
        if (parts != null) return parts;
        List<Part> loaded = new ArrayList<>();
        try (InputStream in = MinecraftClient.getInstance().getResourceManager()
                .getResourceOrThrow(MESH_ID).getInputStream();
             InputStreamReader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            for (JsonElement pe : root.getAsJsonArray("parts")) {
                JsonObject po = pe.getAsJsonObject();
                Part part = new Part();
                part.pump = po.get("pump").getAsBoolean();
                JsonArray quads = po.getAsJsonArray("quads");
                part.data = new float[quads.size() * 4 * 8];
                int k = 0;
                for (JsonElement qe : quads) {
                    for (JsonElement ve : qe.getAsJsonArray()) {
                        for (JsonElement fe : ve.getAsJsonArray()) {
                            part.data[k++] = fe.getAsFloat();
                        }
                    }
                }
                loaded.add(part);
            }
        } catch (Exception e) {
            throw new IllegalStateException("Could not load shotgun mesh " + MESH_ID, e);
        }
        parts = loaded;
        return parts;
    }

    // ---------------------------------------------------------------- rendering
    @Override
    public void render(ItemStack stack, ModelTransformationMode mode, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light, int overlay) {
        List<Part> meshParts = mesh();
        MinecraftClient mc = MinecraftClient.getInstance();

        boolean firstPerson = mode.isFirstPerson();
        boolean thirdPerson = mode == ModelTransformationMode.THIRD_PERSON_LEFT_HAND
                || mode == ModelTransformationMode.THIRD_PERSON_RIGHT_HAND;
        boolean inHand = firstPerson || thirdPerson;

        // ---- animation state (from the item cooldown) ----
        float recoil = 0f;       // 0..1 kick amount
        float pump = 0f;         // 0..1 pump slide amount
        float reloadDip = 0f;    // 0..1 reload tilt
        float shake = 0f;
        ClientPlayerEntity player = mc.player;
        if (inHand && player != null
                && (stack == player.getMainHandStack() || stack == player.getOffHandStack())) {
            float remaining = player.getItemCooldownManager()
                    .getCooldownProgress(ShotgunMod.SHOTGUN, mc.getTickDelta()); // 1 -> 0
            int anim = ShotgunItem.getAnim(stack);
            if (remaining > 0f && anim == 0) {
                float t = (1f - remaining) * ShotgunItem.FIRE_COOLDOWN; // ticks since shot
                recoil = t < 1.5f ? t / 1.5f : (float) Math.exp(-(t - 1.5f) * 0.45f);
                pump = bump(t, 5f, 15f);
            } else if (remaining > 0f && anim == 1) {
                float t = (1f - remaining) * ShotgunItem.RELOAD_COOLDOWN;
                reloadDip = bump(t, 0f, ShotgunItem.RELOAD_COOLDOWN);
                pump = bump(t, 13f, 23f);
                shake = (float) Math.sin(t * 1.7f) * 0.5f * reloadDip;
            }
        }

        matrices.push();
        matrices.translate(0.5, 0.5, 0.5);

        float scale;
        float px, py, pz;
        if (firstPerson) {
            float side = mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND ? -1f : 1f;
            matrices.translate(FP_OFFSET_X * side, FP_OFFSET_Y, FP_OFFSET_Z);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(FP_YAW * side));
            scale = SCALE_HAND;
            px = GRIP_X; py = GRIP_Y; pz = GRIP_Z;
        } else if (thirdPerson) {
            // barrel toward the player's forward
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f));
            scale = SCALE_THIRD;
            px = GRIP_X; py = GRIP_Y; pz = GRIP_Z;
        } else {
            // GUI / ground / item frame: side view, barrel pointing left
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90f));
            scale = SCALE_OTHER;
            px = CENTER_X; py = CENTER_Y; pz = CENTER_Z;
        }

        // animation around the grip (applied in the gun's own frame)
        matrices.translate(0f, 0f, recoil * 0.07f);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(recoil * 9f - reloadDip * 32f + shake * 2f));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(reloadDip * 18f));
        matrices.scale(scale, scale, scale);
        matrices.translate(-px, -py, -pz);

        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        MatrixStack.Entry entry = matrices.peek();
        Matrix4f pos = entry.getPositionMatrix();
        Matrix3f nor = entry.getNormalMatrix();

        for (Part part : meshParts) {
            float dz = part.pump ? pump * PUMP_TRAVEL : 0f; // +Z = toward the stock
            float[] d = part.data;
            for (int i = 0; i < d.length; i += 8) {
                vc.vertex(pos, d[i], d[i + 1], d[i + 2] + dz)
                        .color(255, 255, 255, 255)
                        .texture(d[i + 3], d[i + 4])
                        .overlay(overlay)
                        .light(light)
                        .normal(nor, d[i + 5], d[i + 6], d[i + 7])
                        .next();
            }
        }
        matrices.pop();
    }

    /** Smooth 0 -> 1 -> 0 bump between ticks a and b. */
    private static float bump(float t, float a, float b) {
        float x = MathHelper.clamp((t - a) / (b - a), 0f, 1f);
        return (float) Math.sin(Math.PI * x);
    }
}
