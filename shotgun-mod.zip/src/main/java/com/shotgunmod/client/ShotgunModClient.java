package com.shotgunmod.client;

import org.lwjgl.glfw.GLFW;

import com.shotgunmod.ShotgunItem;
import com.shotgunmod.ShotgunMod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class ShotgunModClient implements ClientModInitializer {
    private static KeyBinding reloadKey;
    private float lastProgress = 0f;

    @Override
    public void onInitializeClient() {
        BuiltinItemRendererRegistry.INSTANCE.register(ShotgunMod.SHOTGUN, new ShotgunRenderer());

        reloadKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.shotgun.reload", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.shotgun"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientPlayerEntity player = client.player;
            if (player == null) return;

            ItemStack held = ItemStack.EMPTY;
            for (Hand hand : Hand.values()) {
                if (player.getStackInHand(hand).getItem() instanceof ShotgunItem) {
                    held = player.getStackInHand(hand);
                    break;
                }
            }

            while (reloadKey.wasPressed()) {
                if (!held.isEmpty()) {
                    ClientPlayNetworking.send(ShotgunMod.RELOAD_PACKET, PacketByteBufs.create());
                }
            }

            // small camera kick the moment a shot goes off (cooldown just started, last action = fire)
            float progress = player.getItemCooldownManager().getCooldownProgress(ShotgunMod.SHOTGUN, 0f);
            if (!held.isEmpty() && progress > 0.9f && lastProgress < 0.5f && ShotgunItem.getAnim(held) == 0) {
                player.setPitch(MathHelper.clamp(player.getPitch() - 3.5f, -90f, 90f));
            }
            lastProgress = progress;
        });
    }
}
