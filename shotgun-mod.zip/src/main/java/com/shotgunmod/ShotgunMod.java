package com.shotgunmod;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;

public class ShotgunMod implements ModInitializer {
    public static final String MOD_ID = "shotgun";

    public static final Item SHOTGUN = new ShotgunItem(new Item.Settings().maxCount(1));
    public static final Item SHELL = new Item(new Item.Settings().maxCount(64));

    public static final Identifier SHOOT_ID = id("shotgun.shoot");
    public static final Identifier RELOAD_ID = id("shotgun.reload");
    public static final SoundEvent SHOOT_SOUND = SoundEvent.of(SHOOT_ID);
    public static final SoundEvent RELOAD_SOUND = SoundEvent.of(RELOAD_ID);

    /** Client -> server packet sent when the reload key (R) is pressed. */
    public static final Identifier RELOAD_PACKET = id("reload");

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    // ---- tiny server-side scheduler (used for delayed blood bursts + casing ejection) ----
    private static final class Task {
        int ticks;
        final Runnable run;

        Task(int ticks, Runnable run) {
            this.ticks = ticks;
            this.run = run;
        }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    public static void schedule(int ticks, Runnable run) {
        TASKS.add(new Task(ticks, run));
    }

    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM, id("shotgun"), SHOTGUN);
        Registry.register(Registries.ITEM, id("shotgun_shell"), SHELL);
        Registry.register(Registries.SOUND_EVENT, SHOOT_ID, SHOOT_SOUND);
        Registry.register(Registries.SOUND_EVENT, RELOAD_ID, RELOAD_SOUND);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            ItemStack loaded = new ItemStack(SHOTGUN);
            ShotgunItem.setAmmo(loaded, ShotgunItem.MAX_AMMO);
            entries.add(loaded);
            entries.add(SHELL);
        });

        ServerPlayNetworking.registerGlobalReceiver(RELOAD_PACKET, (server, player, handler, buf, responseSender) ->
                server.execute(() -> {
                    for (Hand hand : Hand.values()) {
                        ItemStack stack = player.getStackInHand(hand);
                        if (stack.getItem() instanceof ShotgunItem) {
                            ShotgunItem.reload(player, stack);
                            return;
                        }
                    }
                }));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (TASKS.isEmpty()) return;
            List<Task> snapshot = new ArrayList<>(TASKS);
            for (Task t : snapshot) {
                t.ticks--;
                if (t.ticks <= 0) {
                    TASKS.remove(t);
                    t.run.run();
                }
            }
        });
    }
}
