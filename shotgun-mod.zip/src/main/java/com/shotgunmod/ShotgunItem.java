package com.shotgunmod;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.jetbrains.annotations.Nullable;

import net.minecraft.block.Blocks;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * Pump shotgun. Right-click = fire, Sneak + Right-click (or R) = reload.
 * Ammo is stored in the stack NBT ("Ammo"). "Anim" tells the client renderer
 * whether the last action was a shot (0) or a reload (1).
 */
public class ShotgunItem extends Item {
    // ------------------------------------------------------------------ tuning
    public static final int MAX_AMMO = 6;
    public static final int PELLETS = 8;
    public static final int FIRE_COOLDOWN = 22;   // ticks (20 = 1 second)
    public static final int RELOAD_COOLDOWN = 26; // ticks
    public static final double RANGE = 48.0;
    public static final float PELLET_DAMAGE = 3.0f; // per pellet at point blank (x8 pellets)
    public static final double SPREAD = 0.06;        // bigger = wider spread

    public ShotgunItem(Settings settings) {
        super(settings);
    }

    // --------------------------------------------------------------------- nbt
    public static int getAmmo(ItemStack stack) {
        NbtCompound nbt = stack.getNbt();
        return nbt == null ? 0 : nbt.getInt("Ammo");
    }

    public static void setAmmo(ItemStack stack, int ammo) {
        stack.getOrCreateNbt().putInt("Ammo", MathHelper.clamp(ammo, 0, MAX_AMMO));
    }

    public static int getAnim(ItemStack stack) {
        NbtCompound nbt = stack.getNbt();
        return nbt == null ? 0 : nbt.getInt("Anim");
    }

    private static void setAnim(ItemStack stack, int anim) {
        stack.getOrCreateNbt().putInt("Anim", anim);
    }

    // --------------------------------------------------------------------- use
    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);

        if (player.isSneaking()) {
            if (!world.isClient && getAmmo(stack) < MAX_AMMO) {
                reload(player, stack);
            }
            return TypedActionResult.consume(stack);
        }

        if (getAmmo(stack) <= 0) {
            if (!world.isClient) {
                player.sendMessage(Text.translatable("message.shotgun.no_ammo"), true);
                setAnim(stack, 2); // 2 = dry click, no recoil/pump animation
                player.getItemCooldownManager().set(this, 8);
            }
            return TypedActionResult.fail(stack);
        }

        if (world instanceof ServerWorld serverWorld) {
            fire(serverWorld, player, stack);
        }
        return TypedActionResult.consume(stack);
    }

    // -------------------------------------------------------------------- fire
    private void fire(ServerWorld world, PlayerEntity player, ItemStack stack) {
        setAmmo(stack, getAmmo(stack) - 1);
        setAnim(stack, 0);
        player.getItemCooldownManager().set(this, FIRE_COOLDOWN);

        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                ShotgunMod.SHOOT_SOUND, SoundCategory.PLAYERS, 3.0f, 1.0f);

        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0f);
        Vec3d right = look.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-4) {
            right = new Vec3d(1, 0, 0);
        }
        right = right.normalize();
        Vec3d up = right.crossProduct(look).normalize();

        // muzzle flash + smoke
        Vec3d muzzle = eye.add(look.multiply(1.2)).add(up.multiply(-0.12)).add(right.multiply(0.12));
        world.spawnParticles(ParticleTypes.FLAME, muzzle.x, muzzle.y, muzzle.z, 8, 0.04, 0.04, 0.04, 0.04);
        world.spawnParticles(ParticleTypes.LARGE_SMOKE, muzzle.x, muzzle.y, muzzle.z, 4, 0.05, 0.05, 0.05, 0.02);
        world.spawnParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 10, 0.1, 0.1, 0.1, 0.03);

        // collect pellet hits per entity so every pellet counts (no i-frame loss)
        Map<LivingEntity, float[]> hits = new LinkedHashMap<>();
        for (int i = 0; i < PELLETS; i++) {
            double sx = world.random.nextGaussian() * SPREAD;
            double sy = world.random.nextGaussian() * SPREAD;
            Vec3d dir = look.add(right.multiply(sx)).add(up.multiply(sy)).normalize();
            Vec3d end = eye.add(dir.multiply(RANGE));

            BlockHitResult blockHit = world.raycast(new RaycastContext(eye, end,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
            double blockDistSq = blockHit.getType() == HitResult.Type.MISS
                    ? RANGE * RANGE : blockHit.getPos().squaredDistanceTo(eye);

            Box box = player.getBoundingBox().stretch(dir.multiply(RANGE)).expand(1.0);
            EntityHitResult entityHit = ProjectileUtil.raycast(player, eye, end, box,
                    e -> !e.isSpectator() && e.isAlive() && e.canHit() && e instanceof LivingEntity,
                    blockDistSq);

            if (entityHit != null && entityHit.getEntity() instanceof LivingEntity target) {
                double dist = entityHit.getPos().distanceTo(eye);
                float falloff = (float) Math.max(0.25, 1.0 - dist / 32.0);
                float[] data = hits.computeIfAbsent(target, k -> new float[2]);
                data[0] += PELLET_DAMAGE * falloff;
                data[1] += 1;
            } else if (blockHit.getType() != HitResult.Type.MISS) {
                Vec3d p = blockHit.getPos();
                world.spawnParticles(ParticleTypes.SMOKE, p.x, p.y, p.z, 2, 0.05, 0.05, 0.05, 0.01);
            }
        }

        DamageSource source = world.getDamageSources().playerAttack(player);
        for (Map.Entry<LivingEntity, float[]> entry : hits.entrySet()) {
            LivingEntity target = entry.getKey();
            float damage = entry.getValue()[0];
            int pelletHits = (int) entry.getValue()[1];

            target.timeUntilRegen = 0;
            target.damage(source, damage);

            if (target.isDead()) {
                deathBlood(world, target);
            } else {
                bleed(world, target, 6 + pelletHits * 4, 0.05);
            }
        }

        // eject a spent shell out the right side a few ticks later (during the pump)
        final Vec3d port = eye.add(look.multiply(0.5)).add(right.multiply(0.28)).add(up.multiply(-0.2));
        final Vec3d eject = right.multiply(0.18).add(0, 0.14, 0).add(look.multiply(-0.04));
        ShotgunMod.schedule(7, () -> world.spawnParticles(
                new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(ShotgunMod.SHELL)),
                port.x, port.y, port.z, 0, eject.x, eject.y, eject.z, 1.0));
    }

    // ------------------------------------------------------------------- blood
    /** Red-concrete block-break particles scattered over the whole body of the entity. */
    private static void bleed(ServerWorld world, LivingEntity target, int count, double speed) {
        BlockStateParticleEffect fx = new BlockStateParticleEffect(
                ParticleTypes.BLOCK, Blocks.RED_CONCRETE.getDefaultState());
        double w = target.getWidth();
        double h = target.getHeight();
        world.spawnParticles(fx, target.getX(), target.getY() + h * 0.5, target.getZ(),
                count, w * 0.45, h * 0.4, w * 0.45, speed);
    }

    /** Big burst when the shot kills the mob, plus two follow-up bursts during the death animation. */
    private static void deathBlood(ServerWorld world, LivingEntity target) {
        double volume = target.getWidth() * target.getWidth() * target.getHeight();
        int count = (int) MathHelper.clamp(70 + volume * 90, 70, 450);
        bleed(world, target, count, 0.12);
        ShotgunMod.schedule(5, () -> bleed(world, target, count / 2, 0.08));
        ShotgunMod.schedule(12, () -> bleed(world, target, count / 3, 0.05));
    }

    // ------------------------------------------------------------------ reload
    public static void reload(PlayerEntity player, ItemStack stack) {
        if (player.getItemCooldownManager().isCoolingDown(stack.getItem())) {
            return;
        }
        int ammo = getAmmo(stack);
        if (ammo >= MAX_AMMO) {
            return;
        }
        int need = MAX_AMMO - ammo;
        int loaded = player.getAbilities().creativeMode ? need : takeShells(player, need);
        if (loaded <= 0) {
            player.sendMessage(Text.translatable("message.shotgun.no_shells"), true);
            return;
        }
        setAmmo(stack, ammo + loaded);
        setAnim(stack, 1);
        player.getItemCooldownManager().set(stack.getItem(), RELOAD_COOLDOWN);
        player.getWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
                ShotgunMod.RELOAD_SOUND, SoundCategory.PLAYERS, 1.5f, 1.0f);
    }

    private static int takeShells(PlayerEntity player, int need) {
        int got = 0;
        for (int i = 0; i < player.getInventory().size() && got < need; i++) {
            ItemStack s = player.getInventory().getStack(i);
            if (s.isOf(ShotgunMod.SHELL)) {
                int take = Math.min(s.getCount(), need - got);
                s.decrement(take);
                got += take;
            }
        }
        return got;
    }

    // ---------------------------------------------------------------- cosmetics
    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.literal("Shells: " + getAmmo(stack) + " / " + MAX_AMMO).formatted(Formatting.GRAY));
        tooltip.add(Text.literal("Right-click: fire").formatted(Formatting.DARK_GRAY));
        tooltip.add(Text.literal("R or Sneak + Right-click: reload").formatted(Formatting.DARK_GRAY));
    }

    @Override
    public boolean isItemBarVisible(ItemStack stack) {
        return true;
    }

    @Override
    public int getItemBarStep(ItemStack stack) {
        return Math.round(13.0f * getAmmo(stack) / MAX_AMMO);
    }

    @Override
    public int getItemBarColor(ItemStack stack) {
        return 0xFFB000;
    }

    /** Changing ammo NBT must not replay the "item swapped" bob animation (Fabric item API hook). */
    public boolean allowNbtUpdateAnimation(PlayerEntity player, Hand hand, ItemStack oldStack, ItemStack newStack) {
        return false;
    }

    public boolean allowContinuedBlockBreaking(PlayerEntity player, ItemStack oldStack, ItemStack newStack) {
        return true;
    }
}
